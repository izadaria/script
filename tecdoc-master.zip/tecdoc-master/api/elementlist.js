
var ApiGen = ApiGen || {};
ApiGen.elements = [["f","__autoload()"],["c","Cache"],["c","Debug"],["c","Language"],["c","Router"],["c","TecDoc"],["c","Template"]];
